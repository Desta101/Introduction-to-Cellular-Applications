package com.example.carrace.control;
/**
 * shimon Desta 203670286
 * HW01 - Car Game
 **/
public interface CallBack_List {
     void rowSelected(String name, int score, double latitude,double longitude);
}
